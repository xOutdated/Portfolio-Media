const style = document.querySelector("#style")
const button = document.querySelector("#switch")

button.addEventListener("click", () => {
    style.setAttribute("href", "css/style.css")
})