const add = document.querySelector("#add")
const remove = document.querySelector("#remove")

add.addEventListener("click", () => {
    add()
})

remove.addEventListener("click", () => {
    remove()
})

const add = () => {
    let a = document.querySelector("#view");
    let InputText = document.querySelector("#InputText");
    let li = document.createElement("li");
    li.setAttribute('id', inputText.value);
    li.appendChild(document.createTextNode(inputText.value));
    a.appendChild(li);
}

const remove = () => {
    let a = document.querySelector("#view");
    let inputText = document.querySelector("#inputText");
    let item = document.querySelector("#" + inputText.value);
    a.removeChild(item);
}


//parent node = the list itself?
//child = adding an item to the end of the list
//appendchild = adding to the list